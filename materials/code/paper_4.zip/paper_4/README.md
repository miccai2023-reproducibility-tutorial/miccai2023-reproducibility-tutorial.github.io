# Differentiating Alzheimer's Disease from Cognitively Normal Individuals Using Convolutional Neural Networks: A Reproducible Study

With clinica v0.7.5
```
clinica convert oasis-to-bids data/raw data/raw data/bids
clinica run t1-linear data/bids data/caps --random_seed 42
clinicadl prepare-data image data/caps t1-linear -ej extract_image.json
clinica iotools merge-tsv data/bids data/oasis.tsv
```

The analysis of the populations can be done with the following command:
```
python src/demographics.py
```

Fix the arguments of the model so it can be read by
the current version of ClinicaDL:
```
python src/fix_json.py
```

Once your model is trained, make some inferences using ClinicaDL.
```
clinicadl predict models/maps test-OASIS --caps_directory data/caps --participants_tsv data/oasis.tsv
```

Gather the results obtained after applying the network with the following command:
```
python src/gather_results.py
```

A group attribution map of AD patients can be generated with ClinicaDL.
```
clinicadl interpret models/maps test-OASIS gradients gradients --target_node 1 -d AD
```

Run the two following scripts from root to generate the figure and confusion matrix.
The metrics will be printed in the terminal.
```
python src/correlation_figure.py
python src/compute_metrics.py
```

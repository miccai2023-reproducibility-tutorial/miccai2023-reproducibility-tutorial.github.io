# reproducible-repo

## Download data

Open a terminal and execute the following command at the root of the repository
```console
make download-data
```

## Install needed dependencies

Create a conda environment to install Python dependencies.
If you don't have conda installed yet, you can install 
[Miniconda](https://docs.conda.io/en/latest/miniconda.html#latest-miniconda-installer-links).
```
conda env create -f environment.yml
conda activate miccai-reproducibility-tutorial
!/bin/bash -c "$(curl -k https://aramislab.paris.inria.fr/files/software/scripts/install_conda_ants.sh)"
```

Then you need to install ANTs.
https://github.com/cookpa/antsInstallExample
https://github.com/ANTsX/ANTs/wiki/Compiling-ANTs-on-Linux-and-Mac-OS

Possibly Mauricio can fix the conda package?

## Pre-process meta-data

```
clinica convert oasis-to-bids data/raw data/raw data/bids
clinicadl tsvtools get-labels data/bids data/labels.tsv
```
Filter participants younger than 62:
```
python src/filter-qc.py data/preprocessing/labels.tsv data/caps
python src/filter-age.py data/preprocessing/filtered-qc_labels.tsv
```
These steps shouldn't be done by the students as we will give the participants lists


## Spatial registration

Execute the following commands in a terminal at the root of the repository:
```console
clinica run t1-linear data/bids data/caps -rs 42
clinicadl prepare-data image data/caps t1-linear -np 9 -ej extract_image.json
```

## Validation procedure

Split data between train and test:
```console
clinicadl tsvtools split data/preprocessing/filtered-old_labels.tsv --subset_name test --n_test 0.2
```
Split old participants in the training set to create the correct 5-fold:
```console
clinicadl tsvtools kfold data/preprocessing/split/train.tsv
```
Split young participants to then join them to the correct 5-fold:
```console
clinicadl tsvtools kfold data/preprocessing/filtered-young_labels.tsv
python src/join-kfold.py data/preprocessing/split/5_fold data/preprocessing/5_fold data/preprocessing
```

## Fetch the networks

```console
make download-models
```

## Fine-tuning

```console
sh models/transfer.sh old old
sh models/transfer.sh mix old
sh models/transfer.sh mix mix
```

## Predict the performance

```console
sh models/test.sh
python src/gather_results.py models
```

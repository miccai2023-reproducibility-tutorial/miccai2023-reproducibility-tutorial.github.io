import pandas as pd
from pathlib import Path


model_dir = Path("models/maps")
results_dir = Path("results")

results_dir.mkdir(exist_ok=True)

data_df = pd.read_csv(model_dir / "groups" / "test-OASIS" / "data.tsv", sep="\t", usecols=["participant_id"])
results_tsv = results_dir / "test-OASIS_image_level_prediction.tsv"

for split in range(5):
    split_tsv = model_dir / f"split-{split}" / "best-loss" / "test-OASIS" / "test-OASIS_image_level_prediction.tsv"
    split_df = pd.read_csv(split_tsv, sep="\t", usecols=["participant_id", "proba0"])
    split_df.rename({"proba0": f"split-{split}"}, axis=1, inplace=True)
    data_df = pd.merge(data_df, split_df, on="participant_id")

data_df["mean_proba0"] = data_df.mean(axis=1, numeric_only=True)
data_df.to_csv(results_tsv, sep="\t", index=False)


import pandas as pd
from pathlib import Path
from clinicadl.tsvtools.analysis.analysis import demographics_analysis

data_path = Path("data")
results_path = Path("results")
merged_tsv = data_path / "oasis.tsv"
merged_df = pd.read_csv(merged_tsv, sep="\t")
label_df = pd.DataFrame()

for idx in merged_df.index.values:
    label_df.loc[idx, "participant_id"] = merged_df.loc[idx, "participant_id"]
    label_df.loc[idx, "session_id"] = merged_df.loc[idx, "session_id"]
    diagnosis = merged_df.loc[idx, "diagnosis"]
    age = merged_df.loc[idx, "age_bl"]
    if diagnosis == "AD":
        label_df.loc[idx, "diagnosis"] = "AD"
    elif age >= 62:
        label_df.loc[idx, "diagnosis"] = "CN_old"
    else:
        label_df.loc[idx, "diagnosis"] = "CN_young"

label_df.to_csv(data_path / "label.tsv", sep="\t", index=False)
demographics_analysis(
    merged_tsv,
    data_path / "label.tsv",
    results_path / "demographics.tsv",
    diagnoses=["AD", "CN_old", "CN_young"],
)
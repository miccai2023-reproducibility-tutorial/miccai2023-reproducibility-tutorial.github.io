
### Download the models

```
curl https://surfdrive.surf.nl/files/index.php/s/6RTcd9aLtD3kIGA/download -o raw.tar.gz
curl https://www.oasis-brains.org/files/oasis_cross-sectional.csv -o oasis_cross-sectional.csv
```

### Install needed dependencies

```
conda env create -n miccai23
conda activate miccai23
conda install -c conda-forge -c aramislab ants
export ANTSPATH=${$(which antsRegistration)%/*}
```

### Preprocessing

```
clinica convert oasis-to-bids data/raw data/raw data/bids
clinica run t1-linear data/bids data/caps --random_seed 42
clinicadl prepare-data image data/caps t1-linear -ej extract_image.json
clinica iotools merge-tsv data/bids data/oasis.tsv
```

```
python src/demographics.py
```

### Predict

```
clinicadl predict models/maps test-OASIS --caps_directory data/caps --participants_tsv data/oasis.tsv --no-gpu
python src/gather_results.py
```

### Attribution map

```
clinicadl interpret models/maps test-OASIS gradients gradients --no-gpu --target_node 1 -d AD
```

### Generate results

```
python src/correlation_figure.py
python src/compute_metrics.py
```

import pandas as pd
from pathlib import Path

diagnosis_dict = {"CN": 1, "AD": 0}

data_tsv = Path("data/oasis.tsv")
results_dir = Path("results")

confusion_matrix_df = pd.DataFrame(
    index=["AD", "CN_old", "CN_young"],
    columns=["AD", "CN"]
)
confusion_matrix_df.index.name = "true_label/predicted_label"

results_tsv = results_dir / "test-OASIS_image_level_prediction.tsv"
results_df = pd.read_csv(results_tsv, sep="\t")
data_df = pd.read_csv(data_tsv, sep="\t")

df = pd.merge(data_df, results_df, on="participant_id")
df["predicted_label"] = (df["mean_proba0"] < 0.5).astype(int)
df["true_label"] = df.diagnosis.copy()
df.replace({"true_label": diagnosis_dict}, inplace=True)

for pred_diagnosis in ["CN", "AD"]:
    confusion_matrix_df.loc["AD", pred_diagnosis] = len(df[
        (df.true_label == 0) & (df.predicted_label == diagnosis_dict[pred_diagnosis])
    ])
    confusion_matrix_df.loc["CN_old", pred_diagnosis] = len(df[
        (df.true_label == 1) & (df.age_bl >= 62) & (df.predicted_label == diagnosis_dict[pred_diagnosis])
    ])
    confusion_matrix_df.loc["CN_young", pred_diagnosis] = len(df[
        (df.true_label == 1) & (df.age_bl < 62) & (df.predicted_label == diagnosis_dict[pred_diagnosis])
    ])

print(confusion_matrix_df)
confusion_matrix_df.to_csv(results_dir / "confusion_matrix.tsv", sep="\t")

print("(Balanced) accuracy on old population:", (
        confusion_matrix_df.loc["AD", "AD"] + confusion_matrix_df.loc["CN_old", "CN"]
) / 20)
print("Accuracy on all images:", (
        confusion_matrix_df.loc["AD", "AD"] + confusion_matrix_df.loc["CN_old", "CN"] + confusion_matrix_df.loc["CN_young", "CN"]
) / 30)
print("Balanced accuracy on all images:", (
          confusion_matrix_df.loc["AD", "AD"] / 10 +
          (confusion_matrix_df.loc["CN_old", "CN"] + confusion_matrix_df.loc["CN_young", "CN"]) / 20
) / 2)


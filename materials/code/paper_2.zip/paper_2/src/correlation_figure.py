import matplotlib.pyplot as plt
import pandas as pd
from scipy.optimize import curve_fit
from scipy.stats import spearmanr
import numpy as np
from pathlib import Path
from os import makedirs

data_tsv = Path("data/oasis.tsv")
results_dir = Path("results")
makedirs(results_dir / "figures", exist_ok=True)
np.random.seed(42)

variable_dict = {
    "age_bl": "age",
    "MMS": "MMSE",
    "cdr_global": "CDR",
    "sex": "sex"
}


def sigmoid(x, L, x0, k, b):
    return L / (1 + np.exp(-k*(x-x0))) + b


data_df = pd.read_csv(data_tsv, sep="\t")
results_df = pd.read_csv(results_dir / "test-OASIS_image_level_prediction.tsv", sep="\t")
df = pd.merge(data_df, results_df, on="participant_id")

# Fill missing values for clinical scores
df.MMS.fillna(30, inplace=True)
df.cdr_global.fillna(0, inplace=True)

CN_df = df[df.diagnosis == "CN"]
AD_df = df[df.diagnosis == "AD"]

# Continuous variables
for variable in ["age_bl", "MMS"]:

    # Fit regression model
    p0 = [max(df.mean_proba0.values) - min(df.mean_proba0.values), np.mean(df[variable].values), 1, min(df.mean_proba0.values)]
    popt, pcov = curve_fit(sigmoid, df[variable].values, df.mean_proba0.values, p0, method='dogbox')
    x = np.linspace(min(df[variable]), max(df[variable]), 100)
    y = sigmoid(x, *popt)

    y_fit = sigmoid(df[variable], *popt)
    u = ((df.mean_proba0.values - y_fit) ** 2).sum()
    v = ((df.mean_proba0.values - df.mean_proba0.values.mean()) ** 2).sum()
    score = (1 - u/v)
    # print(f"{variable_dict[variable]}: coefficient of determination", score)

    plt.figure()
    plt.scatter(AD_df[variable], AD_df.mean_proba0, label="AD", c="blue")
    plt.scatter(CN_df[variable], CN_df.mean_proba0, label="CN", c="orange")
    plt.axhline(y=0.5, color="grey", linestyle="--")
    plt.plot(x, y, label="model", c="black")
    plt.xlabel(variable_dict[variable])
    plt.ylabel("CN probability")
    plt.legend()
    plt.savefig(results_dir / "figures" / f"test-OASIS_{variable_dict[variable]}_proba0_corr.png")
    plt.close()

# Plot sex distribution
label_list = ["F", "M"]
plt.violinplot([df[df.sex == label].mean_proba0.values for label in label_list])
plt.ylabel("CN probability")
plt.xlabel("sex")
plt.xticks([i + 1 for i in range(len(label_list))], labels=label_list)
plt.savefig(results_dir / "figures" / f"test-OASIS_sex_proba0_corr.png")
plt.close()

# Plot CDR distribution
label_list = [0, 0.5, 1]
plt.violinplot([df[df.cdr_global == label].mean_proba0.values for label in label_list])
plt.ylabel("CN probability")
plt.xlabel("CDR")
plt.xticks([i + 1 for i in range(len(label_list))], labels=label_list)
plt.savefig(results_dir / "figures" / f"test-OASIS_CDR_proba0_corr.png")
plt.close()

for variable in ["sex", "cdr_global", "MMS", "age_bl"]:
    coeff, p = spearmanr(df[variable].values, df.mean_proba0.values)
    print(f"{variable_dict[variable]}\tp-value: {p:.2g} | correlation: {coeff:.2g}")

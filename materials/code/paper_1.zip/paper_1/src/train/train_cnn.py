import tensorflow as tf
from tensorflow.keras import layers, models
from utils import load_data
import numpy as np
import os

results_path = "my_beautiful_folder"

# Split the dataset into training, validation, and test sets
X_train, y_train = load_data(set="train")
X_val, y_val = load_data(set="validation")


def scheduler(epoch, lr):
  if epoch < 10:
    return lr
  else:
    return lr * tf.math.exp(-0.1)


# Define your deep learning model
model = models.Sequential([
    layers.Conv3D(32, kernel_size=3, stride=2, activation='relu', input_shape=(1, 145, 145, 145)),
    layers.Dropout(0.5),
    layers.Conv3D(64, kernel_size=3, stride=1, activation='relu'),
    layers.Dropout(0.5),
    layers.Conv3D(128, kernel_size=3, stride=2, activation='relu'),
    layers.Dropout(0.5),
    layers.Conv3D(128, kernel_size=3, stride=1, activation='relu'),
    layers.Dropout(0.5),
    layers.Conv3D(64, kernel_size=3, stride=2, activation='relu'),
    layers.Dropout(0.5),
    layers.Flatten(),
    layers.Dense(500, activation='relu'),
    layers.Dense(2)
])

# Compile the model
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
              loss='cross_entropy',
              metrics=['accuracy'])

# Train the model
callback = tf.keras.callbacks.LearningRateScheduler(scheduler)
history = model.fit(X_train, y_train, epochs=25, batch_size=16, validation_data=(X_val, y_val), callbacks=[callback])

# Save the model for future use
model.save(f'{results_path}/dementia_detection_model.h5')
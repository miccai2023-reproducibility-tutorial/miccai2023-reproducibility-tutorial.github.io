import numpy as np
from sklearn import preprocessing
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from utils import load_data
import joblib

# Load and preprocess your T1-MRI data. You'll need a dataset of feature vectors extracted from MRI images.
# Make sure to handle data loading and preprocessing according to your dataset structure.

results_path = "my_beautiful_folder"

# Split the dataset into training, validation, and test sets
X_train, y_train = load_data(set="train")
X_val, y_val = load_data(set="validation")
X_test, y_test = load_data(set="test")

# Define and train an SVM model
svm_model = SVC(kernel='linear', C=1.0, random_state=42)
svm_model.fit(X_train, y_train)

# Make predictions on the validation set
y_val_pred = svm_model.predict(X_val)

# Calculate accuracy on the validation set
val_accuracy = accuracy_score(y_val, y_val_pred)
print(f"Validation accuracy: {val_accuracy}")

# Save the SVM model for future use
joblib.dump(svm_model, f'{results_path}/dementia_detection_svm_model.pkl')
import joblib
import numpy as np
from utils import load_data
import matplotlib.pyplot as plt


results_path = "my_beautiful_folder"

X_test = load_data(set="test")
svm_model = joblib.load(f'{results_path}/dementia_detection_svm_model.pkl')

# Calculate the coefficients (weights) of the SVM model
svm_coef = svm_model.coef_[0]

# Calculate the absolute values of the coefficients as feature importance scores
feature_importance = np.abs(svm_coef)

plt.imshow(feature_importance, cmap='viridis')
plt.colorbar()
plt.title('Feature Importance Map')
plt.axis('off')
plt.savefig(f"{results_path}/svm_explanation.png")
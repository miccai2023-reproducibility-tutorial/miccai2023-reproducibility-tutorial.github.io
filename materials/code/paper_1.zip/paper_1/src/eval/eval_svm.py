from sklearn.metrics import accuracy_score
import joblib
from utils import load_data

results_path = "my_beautiful_folder"

X_test = load_data(set="test")
svm_model = joblib.load(f'{results_path}/dementia_detection_svm_model.pkl')

# Evaluate the model on the test set
y_test_pred = svm_model.predict(X_test)
test_accuracy = accuracy_score(y_test, y_test_pred)
print(f"Test accuracy: {test_accuracy}")
import tensorflow as tf
from utils import load_data

results_path = "my_beautiful_folder"

X_test, y_test = load_data(set="test")

model = tf.keras.models.load_model(f'{results_path}/dementia_detection_model.h5')
test_loss, test_accuracy = model.evaluate(X_test, y_test)

print(f"Test accuracy: {test_accuracy}")
| :exclamation: WARNING                                                                                                                                        |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| This repository is a fake repository used for a satellite event of MICCAI 2023. The point of this repo is to show what is leading to irreproducible science. |

# Differentiating Alzheimer's Disease from Cognitively Normal Individuals Using Convolutional Neural Networks: A Reproducible Study

To reproduce the results, please clone the repository. 
Then change directory to the root of the repository to execute the commands.

## Training

The SVM and the CNN can be trained with the following commands:
```bash
python src/train/train_cnn.py
python src/train/train_svm.py
```

## Evaluation

Once trained the models can also be evaluated
```bash
python src/eval/eval_cnn.py
python src/eval/eval_svm.py
```
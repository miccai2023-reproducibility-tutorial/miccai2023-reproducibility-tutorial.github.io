if [ ! -d "data/raw" ]; then
	mkdir raw
	curl https://surfdrive.surf.nl/files/index.php/s/6RTcd9aLtD3kIGA/download -o raw.tar.gz
	tar -xf raw.tar.gz
	mv raw data
	rm raw.tar.gz
fi

curl https://www.oasis-brains.org/files/oasis_cross-sectional.csv -o oasis_cross-sectional.csv
mv oasis_cross-sectional.csv data/raw

curl https://aramislab.paris.inria.fr/clinicadl/files/models/v1.1.0/maps_exp3.tar.gz -o models.tar.gz
tar -xf models.tar.gz
rm models.tar.gz
mv maps models
# Reproduce test results

Depending on your setup the steps you have to follow to reproduce the results of the repo are 
different. Refer to the correct section and execute the given commands:
- [Linux or Mac](#linux-or-mac)
- [Windows](#windows)

## Linux or Mac

### Download data

Open a terminal and execute the following command at the root of the repository
```console
make download-data
```

After executing this command your repo should have the following organization:
```console
reproducible-repo
├── data
│   ├── raw
│   │   ├── OAS1_0001_MR1
│   │   ├── ...
│   │   ├── OAS1_0457_MR1
│   │   └── oasis_crosss-sectional.csv
│   └── fetch.sh
├── src
...
```

### Download the models

Open a terminal and execute the following command at the root of the repository
```console
make download-models
```

After executing this command your models folder should include a `maps` folder:
```
reproducible-repo
├── models
│   ├── maps
│   │   ├── groups
│   │   ├── split-0
│   │   ├── split-1
│   │   ├── split-2
│   │   ├── split-3
│   │   ├── split-4
│   │   ├── environment.txt
│   │   └── maps.json
│   └── fetch.sh
├── src
...
```

### Install needed dependencies

Create a conda environment to install Python dependencies.
If you don't have conda installed yet, you can install 
[Miniconda](https://docs.conda.io/en/latest/miniconda.html#latest-miniconda-installer-links).
```
conda env create -f environment.yml
conda activate miccai-reproducibility-tutorial
conda install -c conda-forge -c aramislab ants=2.4.4 
export ANTSPATH=${$(which antsRegistration)%/*}
```

Check that ANTs was correctly installed by executing `antsRegistration` in your terminal.

To note: you will have to export the path every time you reopen a terminal.

### Preprocessing

These steps format raw data according to the BIDS standard, and apply light preprocessing
(N4 bias correction + linear registration).
```
clinica convert oasis-to-bids data/raw data/raw data/bids
clinica run t1-linear data/bids data/caps --random_seed 42
clinicadl prepare-data image data/caps t1-linear -ej extract_image.json
clinica iotools merge-tsv data/bids data/oasis.tsv
```

The analysis of the populations can be done with the following command:
```
python src/demographics.py
```

### Predict

Fix the arguments of the model so it can be read by
the current version of ClinicaDL:
```
python src/fix_json.py
```

Then execute one of the following commands depending on your setup:

Without CUDA:
```
clinicadl predict models/maps test-OASIS --caps_directory data/caps --participants_tsv data/oasis.tsv --no-gpu
```

With CUDA: 
```
clinicadl predict models/maps test-OASIS --caps_directory data/caps --participants_tsv data/oasis.tsv
```

Gather the results obtained after applying the network with the following command:
```
python src/gather_results.py
```

### Attribution map

A group attribution map of AD patients can be generated with ClinicaDL.

Without CUDA:
```
clinicadl interpret models/maps test-OASIS gradients gradients --no-gpu --target_node 1 -d AD
```

With CUDA:
```
clinicadl interpret models/maps test-OASIS gradients gradients --target_node 1 -d AD
```

### Generate results

Run the two following scripts from root to generate the figure and confusion matrix.
The metrics will be printed in the terminal.

```
python src/correlation_figure.py
python src/compute_metrics.py
```

## Windows

### Download data

Images used in this study were stored on [SurfDrive](https://surfdrive.surf.nl/files/index.php/s/6RTcd9aLtD3kIGA).
Download them locally and put them in this repository, in `data/raw`.

Download the clinical data from the [OASIS website](https://www.oasis-brains.org/#data) by clicking on `Download CSV`.
Put the CSV file `oasis_cross-sectional.csv` in `data/raw`.

After executing the procedure your repo should have the following organisation:
```console
reproducible-repo
├── data
│   ├── raw
│   │   ├── OAS1_0001_MR1
│   │   ├── ...
│   │   ├── OAS1_0457_MR1
│   │   └── oasis_crosss-sectional.csv
│   └── fetch.sh
├── src
...
```

### Download the models

The models were made available by the team which originally trained them on
their [server](https://aramislab.paris.inria.fr/clinicadl/files/models/v1.1.0/maps_exp3.tar.gz).
Place the unzipped folder in `models`.

After executing this command your models folder should include a `maps` folder:
```
reproducible-repo
├── models
│   ├── maps
│   │   ├── groups
│   │   ├── split-0
│   │   ├── split-1
│   │   ├── split-2
│   │   ├── split-3
│   │   ├── split-4
│   │   ├── environment.txt
│   │   └── maps.json
│   └── fetch.sh
├── src
...
```

### Install needed dependencies

Create a conda environment to install Python dependencies.
If you don't have conda installed yet, you can install 
[Miniconda](https://docs.conda.io/en/latest/miniconda.html#latest-miniconda-installer-links).
```
conda env create -f environment.yml
conda activate miccai-reproducibility-tutorial
conda install -c conda-forge -c aramislab ants=2.4.4
export ANTSPATH=${$(which antsRegistration)%/*}
```

Check that ANTs was correctly installed by executing `antsRegistration` in your terminal.

To note: you will have to export the path every time you reopen a terminal.

### Preprocessing

These steps format raw data according to the BIDS standard, and apply light preprocessing
(N4 bias correction + linear registration).
```
clinica convert oasis-to-bids data/raw data/raw data/bids
clinica run t1-linear data/bids data/caps --random_seed 42
clinicadl prepare-data image data/caps t1-linear -ej extract_image.json
clinica iotools merge-tsv data/bids data/oasis.tsv
```

The analysis of the populations can be down with the following command:
```
python src/demographics.tsv
```


### Predict

Fix the arguments of the model so it can be read by
the current version of ClinicaDL:
```
python src/fix_json.py
```

Then execute one of the following commands depending on your setup:

Without CUDA:
```
clinicadl predict models/maps test-OASIS --caps_directory data/caps --participants_tsv data/oasis.tsv --no-gpu
```

With CUDA: 
```
clinicadl predict models/maps test-OASIS --caps_directory data/caps --participants_tsv data/oasis.tsv
```

Gather the results obtained after applying the network with the following command:
```
python src/gather_results.py
```

### Attribution map

A group attribution map of AD patients can be generated with ClinicaDL.

Without CUDA:
```
clinicadl interpret models/maps test-OASIS gradients gradients --no-gpu --target_node 1 -d AD
```

With CUDA:
```
clinicadl interpret models/maps test-OASIS gradients gradients --target_node 1 -d AD
```



### Generate results

Run the two following scripts from root to generate the figure and confusion matrix.
The metrics will be printed in the terminal.

```
python src/correlation_figure.py
python src/compute_metrics.py
```

from pathlib import Path
from typing import Dict, Any


def write_json(data: Dict[str, Any], json_path: Path):
    import json

    json = json.dumps(data, skipkeys=True, ensure_ascii=False, indent=4)
    f = open(json_path, "w")
    f.write(json)
    f.close()


def read_json(json_path: Path):
    import json

    with json_path.open(mode="r") as f:
        json_data = json.load(f)

    return json_data


model_dir = Path("models/maps")
args = read_json(json_path=model_dir / "maps.json")
args["size_reduction"] = False
args["size_reduction_factor"] = 1
args["preprocessing_dict"]["prepare_dl"] = False
write_json(args, json_path=model_dir / "maps.json")

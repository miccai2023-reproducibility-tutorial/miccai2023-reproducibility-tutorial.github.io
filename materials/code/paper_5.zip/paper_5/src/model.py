import torch.nn as nn


class ConvNet(nn.Module):

    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv3d(1, 16, kernel_size=3, padding=1, stride=1),
            nn.InstanceNorm3d(16),
            nn.LeakyReLU(),
            nn.MaxPool3d(kernel_size=2, stride=2),

            nn.Conv3d(16, 32, kernel_size=3, padding=1, stride=1),
            nn.InstanceNorm3d(32),
            nn.LeakyReLU(),
            nn.MaxPool3d(kernel_size=2, stride=2),

            nn.Conv3d(32, 64, kernel_size=3, padding=1, stride=1),
            nn.InstanceNorm3d(64),
            nn.LeakyReLU(),
            nn.MaxPool3d(kernel_size=2, stride=2),

            nn.Conv3d(64, 128, kernel_size=3, padding=1, stride=1),
            nn.InstanceNorm3d(128),
            nn.LeakyReLU(),
            nn.MaxPool3d(kernel_size=2, stride=2),

            nn.Flatten(),
            nn.Linear(1454, 54),
            nn.LeakyReLU(),

            nn.Linear(54, 2)
        )

    def forward(self, x):
        return self.layers(x)

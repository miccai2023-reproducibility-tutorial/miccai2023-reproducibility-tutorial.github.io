# Train best model obtained with the random search
from data import MyDataset
from model import ConvNet
from torch.utils.data import DataLoader
import torch
from os import path, makedirs


def train(train_path, validation_path, results_path):
    train_dataset = MyDataset(train_path)
    train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
    validation_dataset = MyDataset(validation_path)
    validation_loader = DataLoader(validation_dataset, batch_size=8, shuffle=False)

    model = ConvNet().cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=3.31e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0)
    criterion = torch.nn.CrossEntropyLoss()

    best_loss = torch.inf
    makedirs(results_path, exist_ok=True)

    for epochs in range(100):

        model.train()
        for train_batch in train_loader:
            image = train_batch["image"].cuda()
            label = train_batch["label"].cuda()
            output = model(image)
            loss = criterion(output, label)

            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

        model.eval()
        val_loss = 0
        for validation_batch in validation_loader:
            image = validation_batch["image"].cuda()
            label = validation_batch["label"].cuda()
            with torch.no_grad():
                output = model(image)
            val_loss += criterion(output, label).item()

        if val_loss < best_loss:
            torch.save(
                model.state_dict(),
                path.join(results_path, "weights.pt")
            )


if __name__ == "__main__":
    train(train_path="data/train", validation_path="data/validation", results_path="models")

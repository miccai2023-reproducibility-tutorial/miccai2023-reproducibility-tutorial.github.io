import torch
from torch.utils.data import Dataset
import nibabel as nib
from glob import glob
from os import path


class MyDataset(Dataset):

    def __init__(self, data_path):
        self.data_path = data_path
        self.list_files = glob(path.join(data_path, "*.nii.gz"))

    def __len__(self):
        return len(self.list_files)

    def __getitem__(self, item):
        item_path = self.list_files[item]
        item_filename, _ = path.splitext(path.basename(item_path))
        item_keys = {item.split("-")[0]: item.split("-")[1] for item in item_filename.split("_")}
        item_nii = nib.load(item_path)
        item_pt = torch.from_numpy(item_nii.get_fdata()).unsqueeze(0).float()

        return {"image": item_pt, "label": item_keys["label"], "name": item_keys["name"]}

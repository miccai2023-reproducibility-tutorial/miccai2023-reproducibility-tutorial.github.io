# Generate group attribution map for all AD participants in test set
from data import MyDataset
from model import ConvNet
from torch.utils.data import DataLoader
import torch
from os import path, makedirs


def explain(test_path, weights_path, results_path):
    test_dataset = MyDataset(test_path)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)

    model = ConvNet()
    model.load_state_dict(weights_path).cuda()
    model.eval()

    criterion = torch.nn.CrossEntropyLoss()

    makedirs(results_path, exist_ok=True)

    n_AD = 0
    mean_attribution_map = 0

    for test_batch in test_loader:
        label = test_batch["label"].cuda()
        if label.item() == 0:
            image = test_batch["image"].cuda()

            with torch.no_grad():
                output = model(image)
            original_loss = criterion(output, label).item()

            attribution_map = torch.zeros_like(image)
            _, _, x_len, y_len, z_len = image.shape
            for x in range(x_len):
                for y in range(y_len):
                    for z in range(z_len):
                        masked_image = image.copy().cuda()
                        masked_image[
                            :,
                            :,
                            max(0, x - 2):min(x_len - 1, x + 2),
                            max(0, y - 2):min(y_len - 1, y + 2),
                            max(0, z - 2):min(z_len - 1, z + 2),
                        ] = 0.5

                        with torch.no_grad():
                            output = model(masked_image)
                        loss = criterion(output, label).item()
                        attribution_map[:, :, x, y, z] = torch.abs(loss - original_loss)

            torch.save(attribution_map.cpu(), path.join(results_path, f"{test_batch['name']}_map.pt"))
            n_AD += 1
            mean_attribution_map += attribution_map.cpu()

    mean_attribution_map /= n_AD
    torch.save(mean_attribution_map, path.join(results_path, f"mean_map.pt"))

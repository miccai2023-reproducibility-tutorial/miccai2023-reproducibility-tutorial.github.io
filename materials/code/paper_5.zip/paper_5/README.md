| :exclamation: WARNING                                                                                                                                        |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| This repository is a fake repository used for a satellite event of MICCAI 2023. The point of this repo is to show what is leading to irreproducible science. |

# Differentiating Alzheimer’s Disease from Cognitively Normal Individuals Using Convolutional Neural Networks: A Reproducible Study

This repo contains the code used to reproduce the results we obtained in our paper published in MICCAI 2023.
Please refer to our paper for more information.

Pre-trained models are available on request, please contact us: miccai2023-reproducibility-tutorial@proton.me.